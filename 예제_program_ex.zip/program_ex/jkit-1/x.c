main()
{
    int i;
    unsigned char x;
    x = 255;
    for( i = 0 ; i < x ; i ++) printf("i = %d\n",i);
}
